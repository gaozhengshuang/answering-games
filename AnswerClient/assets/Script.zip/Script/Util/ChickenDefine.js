var Define = {
    GAME_STATE: {
        STATE_PENDING: 0,
        STATE_ASKING: 1,
        STATE_ANSWERING: 2,
        STATE_FILTER: 3,
        STATE_FAIL: 4,
        STATE_CHICKEN: 5,
    },
    GAME_RESULT: {
        RESULT_RIGHT: 1,
        RESULT_WROND: 2,
    }
}

module.exports = Define;
