var PlatformDefine = {
    PLATFORM: 'Normal',//'Normal',//'Wechat',//'QQPlay',
    LoginHost: 'dati-service17002.giantfun.cn',
    // LoginPort: 17002,
    LoginSuffix: 'ws_handler',
    RegisteHost: 'https://dati-service17003.giantfun.cn/'
}

module.exports = PlatformDefine;
