cc.Class({
    extends: cc.Component,

    properties: {
        nameLabel: { default: null, type: cc.Label },
        bgSprite: { default: null, type: cc.Sprite },
    },

    fly(info, result, flytime = 5) {
    },
});
