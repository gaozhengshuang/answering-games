cc.Class({
    extends: cc.Component,

    properties: {
        headSprite: { default: null, type: cc.Sprite },
        infoLabel: { default: null, type: cc.RichText },
    },

    fly(info, positiony) {
    },
});
